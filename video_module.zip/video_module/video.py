# ============================================================
# 🎬 VIDEO.PY — GERENCIADOR AUTOMÁTICO DE VÍDEO
# Alex IA Ultra
# Motores: LTX-2.3 Hugging Face + Magic Hour LTX-2.3
# ============================================================

import os
import time
from pathlib import Path
from typing import Optional

import requests
import streamlit as st

try:
    from gradio_client import Client
except ImportError:
    Client = None

LTX_HF_SPACE = "https://lightricks-ltx-2-3.hf.space"
MAGIC_HOUR_BASE_URL = "https://api.magichour.ai/v1"
MAGIC_HOUR_MODELO = "ltx-2.3"
MAGIC_HOUR_RESOLUCAO = "480p"
MAGIC_HOUR_DURACAO = 5
DURACAO_PADRAO = 5

MOTORES_VIDEO = [
    "LTX-2.3 — Hugging Face",
    "Magic Hour — LTX-2.3",
]

CAMERAS = [
    "Sony FX5",
    "Sony FX6",
    "Canon EOS C80",
    "ARRI Alexa Mini LF",
]

PROPORCOES = ["1:1", "16:9", "9:16"]

PASTA = Path("/tmp/alex_ia_ultra_videos")
PASTA.mkdir(parents=True, exist_ok=True)


def obter_api_key_magichour():
    try:
        chave = st.secrets.get("MAGIC_HOUR_API_KEY", "")
    except Exception:
        chave = ""
    if not chave:
        chave = os.environ.get("MAGIC_HOUR_API_KEY", "")
    return str(chave).strip()


def headers_magichour():
    chave = obter_api_key_magichour()
    if not chave:
        raise RuntimeError("MAGIC_HOUR_API_KEY não foi encontrada nos Secrets do Streamlit.")
    return {
        "Authorization": f"Bearer {chave}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def gerar_ltx_huggingface(prompt, duration=5.0, height=512, width=512):
    if Client is None:
        raise RuntimeError("gradio_client não está instalado. Adicione gradio_client ao requirements.txt.")
    if not prompt or not prompt.strip():
        raise ValueError("O prompt do vídeo está vazio.")

    client = Client(LTX_HF_SPACE)
    resultado = client.predict(
        input_image=None,
        prompt=prompt.strip(),
        duration=float(duration),
        enhance_prompt=True,
        seed=0,
        randomize_seed=True,
        height=int(height),
        width=int(width),
        api_name="/generate_video",
    )

    if isinstance(resultado, (tuple, list)):
        if not resultado:
            raise RuntimeError("LTX-2.3 não retornou resultado.")
        caminho_video = resultado[0]
        seed = resultado[1] if len(resultado) > 1 else None
    else:
        caminho_video = resultado
        seed = None

    if not caminho_video:
        raise RuntimeError("LTX-2.3 não retornou o vídeo.")

    return {
        "motor": "LTX-2.3 — Hugging Face",
        "video": str(caminho_video),
        "seed": seed,
    }


def obter_url_upload(extensao):
    extensao = extensao.lower().replace(".", "")
    formatos = ["png", "jpg", "jpeg", "webp", "jfif", "heic", "heif", "avif", "bmp", "tif", "tiff"]
    if extensao not in formatos:
        raise RuntimeError(f"Formato de imagem não suportado: {extensao}")

    resposta = requests.post(
        f"{MAGIC_HOUR_BASE_URL}/files/upload-urls",
        headers=headers_magichour(),
        json={"items": [{"type": "image", "extension": extensao}]},
        timeout=60,
    )
    if resposta.status_code != 200:
        try:
            detalhes = resposta.json()
        except Exception:
            detalhes = resposta.text
        raise RuntimeError(f"Magic Hour retornou HTTP {resposta.status_code} ao solicitar upload:\n{detalhes}")

    resultado = resposta.json()
    itens = resultado.get("items")
    if not itens:
        raise RuntimeError(f"Magic Hour não retornou a lista de upload.\n{resultado}")

    primeiro = itens[0]
    upload_url = primeiro.get("upload_url")
    file_path = primeiro.get("file_path")
    if not upload_url or not file_path:
        raise RuntimeError(f"A resposta não contém upload_url e file_path.\n{resultado}")
    return upload_url, file_path


def enviar_imagem_magichour(imagem_bytes, nome_arquivo):
    extensao = Path(nome_arquivo).suffix.lower().replace(".", "")
    upload_url, file_path = obter_url_upload(extensao)
    resposta = requests.put(upload_url, data=imagem_bytes, timeout=120)
    if resposta.status_code not in [200, 201, 204]:
        raise RuntimeError(f"Falha no upload da imagem.\nHTTP {resposta.status_code}\n{resposta.text}")
    return file_path


def criar_projeto_magichour(file_path, prompt):
    dados = {
        "name": "Alex IA Ultra",
        "end_seconds": MAGIC_HOUR_DURACAO,
        "model": MAGIC_HOUR_MODELO,
        "resolution": MAGIC_HOUR_RESOLUCAO,
        "audio": False,
        "style": {"prompt": prompt.strip()},
        "assets": {"image_file_path": file_path},
    }
    resposta = requests.post(
        f"{MAGIC_HOUR_BASE_URL}/image-to-video",
        headers=headers_magichour(),
        json=dados,
        timeout=120,
    )
    if resposta.status_code not in [200, 201, 202]:
        try:
            detalhes = resposta.json()
        except Exception:
            detalhes = resposta.text
        raise RuntimeError(f"Magic Hour retornou HTTP {resposta.status_code} ao criar vídeo:\n{detalhes}")

    resultado = resposta.json()
    projeto_id = resultado.get("id")
    if not projeto_id:
        raise RuntimeError(f"Magic Hour não retornou o ID do vídeo.\n{resultado}")
    return projeto_id, resultado


def consultar_projeto_magichour(projeto_id):
    urls = [
        f"{MAGIC_HOUR_BASE_URL}/video-projects/{projeto_id}",
        f"{MAGIC_HOUR_BASE_URL}/image-to-video/{projeto_id}",
    ]
    ultimo_erro = None
    for url in urls:
        try:
            resposta = requests.get(url, headers=headers_magichour(), timeout=60)
        except Exception as erro:
            ultimo_erro = str(erro)
            continue
        if resposta.status_code == 200:
            try:
                return resposta.json()
            except Exception:
                return {}
        ultimo_erro = f"HTTP {resposta.status_code}: {resposta.text}"
    raise RuntimeError(f"Não foi possível consultar o projeto.\n{ultimo_erro}")


def encontrar_download_magichour(dados):
    if not isinstance(dados, dict):
        return None

    for campo in ["video_url", "download_url", "output_url", "url"]:
        valor = dados.get(campo)
        if isinstance(valor, str) and valor.startswith("http"):
            return valor

    downloads = dados.get("downloads")
    if isinstance(downloads, dict):
        valores = downloads.values()
    elif isinstance(downloads, list):
        valores = downloads
    else:
        valores = []

    for valor in valores:
        if isinstance(valor, str) and valor.startswith("http"):
            return valor
        if isinstance(valor, dict):
            for chave in ["url", "download_url"]:
                url = valor.get(chave)
                if isinstance(url, str) and url.startswith("http"):
                    return url

    output = dados.get("output")
    if isinstance(output, dict):
        for valor in output.values():
            if isinstance(valor, str) and valor.startswith("http"):
                return valor
    return None


def baixar_video_magichour(url, nome="video_magichour.mp4"):
    resposta = requests.get(url, timeout=180)
    if resposta.status_code != 200:
        raise RuntimeError(f"Falha ao baixar o vídeo.\nHTTP {resposta.status_code}")
    caminho = PASTA / nome
    caminho.write_bytes(resposta.content)
    return str(caminho)


def gerar_magichour(imagem_bytes, nome_arquivo, prompt, timeout_segundos=300):
    if not imagem_bytes:
        raise ValueError("O Magic Hour precisa de uma imagem.")
    if not prompt or not prompt.strip():
        raise ValueError("O prompt do vídeo está vazio.")

    file_path = enviar_imagem_magichour(imagem_bytes, nome_arquivo)
    projeto_id, resultado = criar_projeto_magichour(file_path, prompt)
    inicio = time.time()
    ultimo_resultado = resultado
    video_url = encontrar_download_magichour(ultimo_resultado)

    while not video_url:
        if time.time() - inicio >= timeout_segundos:
            raise RuntimeError(f"Tempo limite atingido no Magic Hour.\nÚltima resposta:\n{ultimo_resultado}")
        time.sleep(5)
        ultimo_resultado = consultar_projeto_magichour(projeto_id)
        status = str(ultimo_resultado.get("status", "processing")).lower()
        if status in ["failed", "error", "cancelled"]:
            raise RuntimeError(f"A geração no Magic Hour falhou.\n{ultimo_resultado}")
        video_url = encontrar_download_magichour(ultimo_resultado)

    caminho = baixar_video_magichour(video_url)
    return {
        "motor": "Magic Hour — LTX-2.3",
        "video": caminho,
        "projeto_id": projeto_id,
        "url": video_url,
    }


def gerar_video_automatico(
    prompt,
    imagem_bytes=None,
    nome_imagem="imagem.png",
    duracao=5.0,
    width=512,
    height=512,
):
    """Com imagem: Magic Hour -> LTX Hugging Face. Sem imagem: LTX Hugging Face."""
    erros = []

    if imagem_bytes:
        try:
            resultado = gerar_magichour(imagem_bytes, nome_imagem, prompt)
            resultado["fallback"] = False
            resultado["erros_anteriores"] = erros
            return resultado
        except Exception as erro:
            erros.append("Magic Hour: " + str(erro))

    try:
        resultado = gerar_ltx_huggingface(
            prompt=prompt,
            duration=duracao,
            height=height,
            width=width,
        )
        resultado["fallback"] = bool(erros)
        resultado["erros_anteriores"] = erros
        return resultado
    except Exception as erro:
        erros.append("LTX-2.3 Hugging Face: " + str(erro))

    raise RuntimeError(
        "❌ NENHUM MOTOR DE VÍDEO CONSEGUIU GERAR O VÍDEO.\n\n" +
        "\n\n".join(erros)
    )


def gerar_video(
    prompt,
    imagem_bytes=None,
    nome_imagem="imagem.png",
    duracao=5.0,
    width=512,
    height=512,
):
    return gerar_video_automatico(
        prompt=prompt,
        imagem_bytes=imagem_bytes,
        nome_imagem=nome_imagem,
        duracao=duracao,
        width=width,
        height=height,
    )


def gerar_video_texto(prompt, duracao=5.0):
    return gerar_ltx_huggingface(prompt, duration=duracao)


def gerar_video_imagem(imagem_bytes, nome_imagem, prompt):
    return gerar_magichour(imagem_bytes, nome_imagem, prompt)


def listar_motores():
    return {
        "motores": MOTORES_VIDEO,
        "cameras": CAMERAS,
        "proporcoes": PROPORCOES,
        "duracao_padrao": DURACAO_PADRAO,
    }


if __name__ == "__main__":
    st.set_page_config(
        page_title="Alex IA Ultra — Vídeo",
        page_icon="🎬",
        layout="wide",
    )
    st.title("🎬 Alex IA Ultra — Teste de Vídeo")
    st.caption("LTX-2.3 + Magic Hour • Seleção automática")
    st.info("🖼️ Com imagem: Magic Hour → LTX-2.3\n\n📝 Sem imagem: LTX-2.3 — Hugging Face")

    imagem = st.file_uploader(
        "🖼️ Imagem opcional",
        type=["png", "jpg", "jpeg", "webp"],
    )
    if imagem:
        st.image(imagem, caption="Imagem de entrada", use_container_width=True)

    prompt = st.text_area(
        "📝 Descrição do vídeo",
        value=(
            "O personagem começa a caminhar lentamente para frente. "
            "A câmera acompanha suavemente o personagem. "
            "Movimento cinematográfico natural e estável. "
            "Manter o mesmo personagem, rosto, cabelo, roupa, aparência e identidade durante toda a cena."
        ),
        height=180,
    )

    if st.button("🎬 GERAR VÍDEO AUTOMATICAMENTE", type="primary", use_container_width=True):
        if not prompt.strip():
            st.warning("⚠️ Digite uma descrição.")
            st.stop()

        try:
            resultado = gerar_video_automatico(
                prompt=prompt,
                imagem_bytes=imagem.getvalue() if imagem else None,
                nome_imagem=imagem.name if imagem else "imagem.png",
            )
            st.success("🎉 VÍDEO GERADO COM SUCESSO!")
            st.write("🎬 Motor utilizado:")
            st.code(resultado.get("motor", "Desconhecido"))
            st.video(resultado["video"])
            if resultado.get("fallback"):
                st.warning("⚠️ O primeiro motor falhou. O segundo motor foi utilizado automaticamente.")
            if resultado.get("seed") is not None:
                st.write("🎲 Seed utilizada:")
                st.code(str(resultado["seed"]))
        except Exception as erro:
            st.error("❌ Erro durante a geração.")
            st.code(str(erro))
