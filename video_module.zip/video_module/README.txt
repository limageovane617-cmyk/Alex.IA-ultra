PASTA DO GERENCIADOR DE VÍDEO — ALEX IA ULTRA

Arquivo principal:
video.py

Dependência adicional:
gradio_client

Secret necessário para o Magic Hour:
MAGIC_HOUR_API_KEY

Fluxo automático:
- Com imagem: Magic Hour -> LTX-2.3 Hugging Face
- Sem imagem: LTX-2.3 Hugging Face

O arquivo mantém as duas implementações baseadas nos testes enviados.
